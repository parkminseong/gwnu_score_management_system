# gwnu_score_management_system
강릉원주대학교 학생 성적 관리 시스템 
